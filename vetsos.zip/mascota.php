<?php
require_once ('template.php');
?>
<!DOCTYPE html>
<html lang="en">
<?=Head('mascota')?>

<?=starBody()?>

<h1>registrar cliente </h1>
<?=endBody()?>