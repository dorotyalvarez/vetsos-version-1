function hi() {
    alert("sirva ");
}