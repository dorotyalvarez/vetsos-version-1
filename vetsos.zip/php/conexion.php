<?php
  $host = 'localhost';
  $user = 'root';
  $password = '';
  $db = 'login_register';

  $conection = @mysqli_connect($host, $user, $password, $db); //Conexión a la base de datos
  

?>