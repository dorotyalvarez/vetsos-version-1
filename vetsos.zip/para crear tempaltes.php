<?php
require_once ('template.php');
?>
<!DOCTYPE html>
<html lang="en">
<?=Head('citas')?>

<?=starBody()?>

<h1>citas </h1>




<?=endBody()?>